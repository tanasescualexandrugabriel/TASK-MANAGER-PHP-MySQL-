-- database.sql
-- Script de creare a bazei de date și a tabelei pentru Task Manager

CREATE DATABASE IF NOT EXISTS task_manager
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_general_ci;

USE task_manager;

CREATE TABLE IF NOT EXISTS tasks (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(150) NOT NULL,
    description TEXT NULL,
    due_date DATE NULL,
    status ENUM('pending', 'done') NOT NULL DEFAULT 'pending',
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Date de exemplu (opțional, pentru testare rapidă)
INSERT INTO tasks (title, description, due_date, status) VALUES
('Configurare server local', 'Instalare XAMPP și verificare funcționare PHP + MySQL', '2026-08-15', 'done'),
('Scriere schema bazei de date', 'Creare tabelă tasks cu toate câmpurile necesare', '2026-08-16', 'done'),
('Implementare pagină listă sarcini', 'Afișare toate sarcinile din baza de date', '2026-08-18', 'pending'),
('Implementare adăugare sarcină', 'Formular de creare sarcină nouă', '2026-08-20', 'pending'),
('Testare aplicație', 'Verificare completă funcționalități CRUD', '2026-08-25', 'pending');
