    </main>
    <footer class="app-footer">
        <p>Task Manager &mdash; proiect PHP + MySQL</p>
    </footer>
</body>
</html>
