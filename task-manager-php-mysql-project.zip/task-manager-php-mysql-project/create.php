<?php
require_once "config/database.php";

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $due_date = trim($_POST['due_date'] ?? '');

    if ($title === '') {
        $errors[] = "Titlul este obligatoriu.";
    }

    if (empty($errors)) {
        $stmt = $pdo->prepare(
            "INSERT INTO tasks (title, description, due_date, status)
             VALUES (:title, :description, :due_date, 'pending')"
        );
        $stmt->execute([
            ':title' => $title,
            ':description' => $description !== '' ? $description : null,
            ':due_date' => $due_date !== '' ? $due_date : null,
        ]);

        header("Location: index.php?success=1");
        exit;
    }
}

require_once "includes/header.php";
?>

<h2>Sarcină nouă</h2>

<?php foreach ($errors as $error): ?>
    <div class="alert alert-success" style="background-color:#fdecea;color:#c62828;">
        <?= htmlspecialchars($error) ?>
    </div>
<?php endforeach; ?>

<form method="POST" action="create.php">
    <label for="title">Titlu *</label>
    <input type="text" id="title" name="title" value="<?= htmlspecialchars($_POST['title'] ?? '') ?>" required>

    <label for="description">Descriere</label>
    <textarea id="description" name="description"><?= htmlspecialchars($_POST['description'] ?? '') ?></textarea>

    <label for="due_date">Termen limită</label>
    <input type="date" id="due_date" name="due_date" value="<?= htmlspecialchars($_POST['due_date'] ?? '') ?>">

    <div class="form-actions">
        <button type="submit" class="btn btn-primary">Salvează</button>
        <a href="index.php" class="btn btn-secondary">Anulează</a>
    </div>
</form>

<?php require_once "includes/footer.php"; ?>
