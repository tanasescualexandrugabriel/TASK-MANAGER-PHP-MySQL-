<?php
require_once "config/database.php";

$id = isset($_GET['id']) ? (int) $_GET['id'] : 0;

if ($id <= 0) {
    header("Location: index.php");
    exit;
}

// Preluăm sarcina existentă
$stmt = $pdo->prepare("SELECT * FROM tasks WHERE id = :id");
$stmt->execute([':id' => $id]);
$task = $stmt->fetch();

if (!$task) {
    header("Location: index.php");
    exit;
}

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $due_date = trim($_POST['due_date'] ?? '');
    $status = $_POST['status'] ?? 'pending';

    if ($title === '') {
        $errors[] = "Titlul este obligatoriu.";
    }

    if (!in_array($status, ['pending', 'done'], true)) {
        $status = 'pending';
    }

    if (empty($errors)) {
        $stmt = $pdo->prepare(
            "UPDATE tasks
             SET title = :title, description = :description, due_date = :due_date, status = :status
             WHERE id = :id"
        );
        $stmt->execute([
            ':title' => $title,
            ':description' => $description !== '' ? $description : null,
            ':due_date' => $due_date !== '' ? $due_date : null,
            ':status' => $status,
            ':id' => $id,
        ]);

        header("Location: index.php?success=1");
        exit;
    }

    // păstrăm valorile introduse, ca să nu se piardă la eroare
    $task['title'] = $title;
    $task['description'] = $description;
    $task['due_date'] = $due_date;
    $task['status'] = $status;
}

require_once "includes/header.php";
?>

<h2>Editează sarcina</h2>

<?php foreach ($errors as $error): ?>
    <div class="alert alert-success" style="background-color:#fdecea;color:#c62828;">
        <?= htmlspecialchars($error) ?>
    </div>
<?php endforeach; ?>

<form method="POST" action="update.php?id=<?= $id ?>">
    <label for="title">Titlu *</label>
    <input type="text" id="title" name="title" value="<?= htmlspecialchars($task['title']) ?>" required>

    <label for="description">Descriere</label>
    <textarea id="description" name="description"><?= htmlspecialchars($task['description'] ?? '') ?></textarea>

    <label for="due_date">Termen limită</label>
    <input type="date" id="due_date" name="due_date" value="<?= htmlspecialchars($task['due_date'] ?? '') ?>">

    <label for="status">Status</label>
    <select id="status" name="status">
        <option value="pending" <?= $task['status'] === 'pending' ? 'selected' : '' ?>>În așteptare</option>
        <option value="done" <?= $task['status'] === 'done' ? 'selected' : '' ?>>Finalizată</option>
    </select>

    <div class="form-actions">
        <button type="submit" class="btn btn-primary">Salvează modificările</button>
        <a href="index.php" class="btn btn-secondary">Anulează</a>
    </div>
</form>

<?php require_once "includes/footer.php"; ?>
