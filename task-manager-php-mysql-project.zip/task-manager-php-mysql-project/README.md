# Task Manager (PHP + MySQL)

Aplicație web simplă de tip CRUD (Create, Read, Update, Delete) pentru gestionarea unei liste
de sarcini (to-do list), realizată în PHP procedural și MySQL, folosind PDO pentru conexiunea
la baza de date (protecție împotriva SQL injection prin prepared statements).

## Funcționalități

- Adăugare sarcină nouă (titlu, descriere, status, dată limită)
- Vizualizare listă completă de sarcini
- Editare sarcină existentă
- Ștergere sarcină
- Marcare sarcină ca finalizată / nefinalizată
- Interfață simplă, responsive, fără framework JS

## Structură proiect

```
task-manager-php/
├── README.md
├── database.sql
├── config/
│   └── database.php
├── includes/
│   ├── header.php
│   └── footer.php
├── assets/
│   └── style.css
├── index.php
├── create.php
├── update.php
├── delete.php
└── toggle_status.php
```

## Cerințe

- PHP 7.4+ (recomandat PHP 8+)
- MySQL 5.7+ sau MariaDB
- Extensia PDO activată (implicit activă în majoritatea instalărilor PHP)

## Instalare

1. Creezi baza de date rulând scriptul `database.sql` în MySQL:
   ```sql
   SOURCE database.sql;
   ```
   sau importă fișierul direct din phpMyAdmin.

2. Editezi datele de conectare din `config/database.php` (host, user, parolă, nume bază de date).

3. Pui folderul proiectului în directorul serverului web (ex: `htdocs` pentru XAMPP,
   `www` pentru WAMP, sau `/var/www/html` pe Linux).

4. Accesezi în browser: `http://localhost/task-manager-php/`

## Structura bazei de date

Tabela `tasks`:

| Coloană      | Tip           | Descriere                          |
|--------------|---------------|-------------------------------------|
| id           | INT, PK, AI   | Identificator unic                  |
| title        | VARCHAR(150)  | Titlul sarcinii                     |
| description  | TEXT          | Descriere detaliată (opțional)      |
| due_date     | DATE          | Dată limită (opțional)              |
| status       | ENUM          | 'pending' sau 'done'                |
| created_at   | TIMESTAMP     | Data creării, generată automat      |


## Ce am învățat / tehnologii folosite

- PHP procedural, conectat la MySQL prin PDO
- Prepared statements pentru prevenirea SQL injection
- Operații CRUD complete
- Structurare a unui proiect PHP (separare config / includes / pagini)
- HTML semantic + CSS simplu, fără framework


