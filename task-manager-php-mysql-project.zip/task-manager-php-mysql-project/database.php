<?php
/**
 * config/database.php
 * Realizează conexiunea la baza de date MySQL folosind PDO.
 * Editează valorile de mai jos conform configurației locale.
 */

$db_host = "localhost";
$db_name = "task_manager";
$db_user = "root";
$db_pass = "";

try {
    $pdo = new PDO(
        "mysql:host={$db_host};dbname={$db_name};charset=utf8mb4",
        $db_user,
        $db_pass,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]
    );
} catch (PDOException $e) {
    die("Eroare la conectarea la baza de date: " . htmlspecialchars($e->getMessage()));
}
