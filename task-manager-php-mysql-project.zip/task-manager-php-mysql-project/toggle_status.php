<?php
require_once "config/database.php";

$id = isset($_GET['id']) ? (int) $_GET['id'] : 0;

if ($id > 0) {
    $stmt = $pdo->prepare("SELECT status FROM tasks WHERE id = :id");
    $stmt->execute([':id' => $id]);
    $task = $stmt->fetch();

    if ($task) {
        $new_status = $task['status'] === 'done' ? 'pending' : 'done';

        $update = $pdo->prepare("UPDATE tasks SET status = :status WHERE id = :id");
        $update->execute([':status' => $new_status, ':id' => $id]);
    }
}

header("Location: index.php?success=1");
exit;
