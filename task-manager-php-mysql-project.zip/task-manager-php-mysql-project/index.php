<?php
require_once "config/database.php";

// Preluăm toate sarcinile din baza de date, cele mai recente primele
$stmt = $pdo->query("SELECT * FROM tasks ORDER BY created_at DESC");
$tasks = $stmt->fetchAll();

require_once "includes/header.php";
?>

<?php if (isset($_GET['success'])): ?>
    <div class="alert alert-success">Operațiune realizată cu succes.</div>
<?php endif; ?>

<div class="actions-bar">
    <a href="create.php" class="btn btn-primary">+ Sarcină nouă</a>
</div>

<table>
    <thead>
        <tr>
            <th>Titlu</th>
            <th>Termen</th>
            <th>Status</th>
            <th>Acțiuni</th>
        </tr>
    </thead>
    <tbody>
        <?php if (count($tasks) === 0): ?>
            <tr>
                <td colspan="4">Nu există nicio sarcină momentan.</td>
            </tr>
        <?php else: ?>
            <?php foreach ($tasks as $task): ?>
                <tr>
                    <td>
                        <strong><?= htmlspecialchars($task['title']) ?></strong>
                        <?php if (!empty($task['description'])): ?>
                            <br><small><?= htmlspecialchars($task['description']) ?></small>
                        <?php endif; ?>
                    </td>
                    <td><?= $task['due_date'] ? htmlspecialchars($task['due_date']) : '—' ?></td>
                    <td>
                        <span class="status-<?= $task['status'] ?>">
                            <?= $task['status'] === 'done' ? 'Finalizată' : 'În așteptare' ?>
                        </span>
                    </td>
                    <td>
                        <a href="toggle_status.php?id=<?= $task['id'] ?>" class="btn btn-secondary">
                            <?= $task['status'] === 'done' ? 'Marchează nefinalizată' : 'Marchează finalizată' ?>
                        </a>
                        <a href="update.php?id=<?= $task['id'] ?>" class="btn btn-primary">Editează</a>
                        <a href="delete.php?id=<?= $task['id'] ?>" class="btn btn-danger"
                           onclick="return confirm('Sigur vrei să ștergi această sarcină?');">Șterge</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        <?php endif; ?>
    </tbody>
</table>

<?php require_once "includes/footer.php"; ?>
